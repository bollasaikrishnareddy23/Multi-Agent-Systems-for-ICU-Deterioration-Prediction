# ICU Deterioration Prediction with 3 Agents

This starter project builds a 3-agent ICU deterioration prediction system using MIMIC-IV style data.

Agents:
1. Kidney Failure Agent
2. Vital Signs Agent
3. Mechanical Ventilation Agent
4. Supervisor Agent combines the three outputs

## Recommended project definition

Input:
- First 24 hours after ICU admission

Prediction target:
- Hospital mortality, using `hospital_expire_flag`
- Later you can replace this with a stronger deterioration label.

## Step 1: Install packages

```bash
pip install -r requirements.txt
```

## Step 2: Test the project without MIMIC

Run:

```bash
python src/create_sample_data.py
python src/run_rule_based_agents.py
python src/train_ml_baseline.py
```

Expected outputs:
- `data/sample_features.csv`
- `results/rule_based_predictions.csv`
- `results/ml_metrics.json`

## Step 3: Get MIMIC-IV access

You need credentialed PhysioNet access.
Then use BigQuery access to the MIMIC-IV v3.1 tables.

Useful table families:
- `physionet-data.mimiciv_v3_1_hosp`
- `physionet-data.mimiciv_v3_1_icu`

Some projects also use derived tables such as:
- `physionet-data.mimiciv_derived.vitalsign`
- `physionet-data.mimiciv_derived.chemistry`
- `physionet-data.mimiciv_derived.urine_output`
- `physionet-data.mimiciv_derived.ventilation`

If derived tables are unavailable, create them from the official MIMIC Code Repository.

## Step 4: Run the SQL files

Run these in BigQuery:

1. `sql/01_create_cohort_bigquery.sql`
2. `sql/02_create_features_bigquery.sql`

Export the final features table to CSV as:

```text
data/mimic_features.csv
```

It should contain one row per ICU stay.

## Step 5: Run agents on real data

After exporting your feature CSV, modify the input path in:

```text
src/run_rule_based_agents.py
```

Change:

```python
input_path = "data/sample_features.csv"
```

to:

```python
input_path = "data/mimic_features.csv"
```

Then run:

```bash
python src/run_rule_based_agents.py
python src/train_ml_baseline.py
```

## Required final columns

Your final feature CSV should include:

```text
stay_id
subject_id
hadm_id
anchor_age
gender
hospital_expire_flag

creatinine_max_24h
creatinine_first_24h
creatinine_last_24h
bun_max_24h
urine_output_24h
dialysis_flag_24h

heart_rate_max_24h
map_min_24h
sbp_min_24h
resp_rate_max_24h
spo2_min_24h
temperature_max_24h
temperature_min_24h

mechanical_ventilation_flag_24h
oxygen_support_flag_24h
fio2_max_24h
peep_max_24h
```

## Report structure

1. Introduction
2. Dataset and cohort selection
3. Feature extraction
4. Three-agent architecture
5. Supervisor agent
6. Experiments
7. Results
8. Example patient explanation
9. Limitations
10. Conclusion
